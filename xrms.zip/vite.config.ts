import { defineConfig } from "vite"
import { VitePluginNode } from "vite-plugin-node"
import tsconfigPaths from "vite-tsconfig-paths"

export default defineConfig({
  server: {
    port: 5000,
  },
  plugins: [
    ...VitePluginNode({
      adapter: "express",
      appPath: "./src/server.ts",
      exportName: "viteNodeApp",
      tsCompiler: "esbuild",
      swcOptions: {},
    }),
    tsconfigPaths(),
  ],
  optimizeDeps: {
    exclude: ["@prisma/client"],
  },
  build: {
    sourcemap: true,
  },
})

