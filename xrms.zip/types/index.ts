export interface Machine {
  id: string
  name: string
  status: "available" | "in-use" | "maintenance"
}

export interface Alert {
  id: string
  type: "breakdown" | "maintenance" | "highWaitTime" | "queueThreshold"
  message: string
  timestamp: string
}

export interface MaintenanceSchedule {
  id: string
  machineName: string
  date: string
  type: "routine" | "repair"
  technician: string
}

export interface Appointment {
  id: string
  patientName: string
  patientId: string
  machineId: string
  scheduledTime: string
  duration: number
}

export interface Patient {
  id: string
  name: string
  dateOfBirth: string
  contactNumber: string
}

