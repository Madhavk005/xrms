"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { CheckCircleIcon, ExclamationCircleIcon, XCircleIcon } from "@heroicons/react/24/solid"
import Link from "next/link"
import type { Machine } from "@/types"
import { fetchMachines, subscribeToMachineUpdates } from "@/lib/api"

export default function MachineStatus() {
  const [machines, setMachines] = useState<Machine[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await fetchMachines()
        setMachines(data)
        setIsLoading(false)
      } catch (err) {
        setError("Failed to fetch machine data. Please try again later.")
        setIsLoading(false)
      }
    }

    fetchData()

    const unsubscribe = subscribeToMachineUpdates((updatedMachine) => {
      setMachines((prevMachines) =>
        prevMachines.map((machine) => (machine.id === updatedMachine.id ? updatedMachine : machine)),
      )
    })

    return () => {
      unsubscribe()
    }
  }, [])

  if (isLoading) return <div>Loading machine status...</div>
  if (error) return <div className="text-red-500">{error}</div>

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-semibold mb-6">Machine Status</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {machines.map((machine, index) => (
          <motion.div
            key={machine.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-gray-50 rounded-lg p-4 flex items-center justify-between"
          >
            <Link href={`/dashboard/machines/${machine.id}`} className="flex-1">
              <div>
                <h3 className="font-medium text-lg">{machine.name}</h3>
                <p className={`text-sm ${getStatusTextColor(machine.status)}`}>{machine.status}</p>
              </div>
            </Link>
            {getStatusIcon(machine.status)}
          </motion.div>
        ))}
      </div>
    </div>
  )
}

function getStatusTextColor(status: Machine["status"]) {
  switch (status) {
    case "available":
      return "text-green-600"
    case "in-use":
      return "text-yellow-600"
    case "maintenance":
      return "text-red-600"
  }
}

function getStatusIcon(status: Machine["status"]) {
  switch (status) {
    case "available":
      return <CheckCircleIcon className="h-8 w-8 text-green-500" />
    case "in-use":
      return <ExclamationCircleIcon className="h-8 w-8 text-yellow-500" />
    case "maintenance":
      return <XCircleIcon className="h-8 w-8 text-red-500" />
  }
}

