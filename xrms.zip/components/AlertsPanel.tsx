"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ExclamationTriangleIcon, ClockIcon, QueueListIcon } from "@heroicons/react/24/solid"
import type { Alert } from "@/types"
import { fetchAlerts, subscribeToAlerts } from "@/lib/api"

export default function AlertsPanel() {
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await fetchAlerts()
        setAlerts(data)
        setIsLoading(false)
      } catch (err) {
        setError("Failed to fetch alerts. Please try again later.")
        setIsLoading(false)
      }
    }

    fetchData()

    const unsubscribe = subscribeToAlerts((newAlert) => {
      setAlerts((prevAlerts) => [newAlert, ...prevAlerts])
    })

    return () => {
      unsubscribe()
    }
  }, [])

  if (isLoading) return <div>Loading alerts...</div>
  if (error) return <div className="text-red-500">{error}</div>

  return (
    <div className="bg-white rounded-lg shadow-md p-6 h-full">
      <h2 className="text-2xl font-semibold mb-6">Alerts</h2>
      <div className="space-y-4 max-h-[calc(100vh-12rem)] overflow-y-auto">
        <AnimatePresence>
          {alerts.map((alert) => (
            <motion.div
              key={alert.id}
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className={`p-4 rounded-lg ${getAlertColor(alert.type)} flex items-start`}
            >
              {getAlertIcon(alert.type)}
              <div className="ml-3 flex-1">
                <div className="flex justify-between items-start">
                  <div className="font-semibold">{getAlertTitle(alert.type)}</div>
                  <div className="text-xs">{new Date(alert.timestamp).toLocaleTimeString()}</div>
                </div>
                <p className="mt-1 text-sm">{alert.message}</p>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  )
}

function getAlertColor(type: Alert["type"]) {
  switch (type) {
    case "breakdown":
      return "bg-red-100 text-red-800"
    case "maintenance":
      return "bg-yellow-100 text-yellow-800"
    case "highWaitTime":
      return "bg-orange-100 text-orange-800"
    case "queueThreshold":
      return "bg-blue-100 text-blue-800"
  }
}

function getAlertIcon(type: Alert["type"]) {
  const iconClass = "h-6 w-6 mt-0.5"
  switch (type) {
    case "breakdown":
      return <ExclamationTriangleIcon className={`${iconClass} text-red-600`} />
    case "maintenance":
      return <ExclamationTriangleIcon className={`${iconClass} text-yellow-600`} />
    case "highWaitTime":
      return <ClockIcon className={`${iconClass} text-orange-600`} />
    case "queueThreshold":
      return <QueueListIcon className={`${iconClass} text-blue-600`} />
  }
}

function getAlertTitle(type: Alert["type"]) {
  switch (type) {
    case "breakdown":
      return "Machine Breakdown"
    case "maintenance":
      return "Maintenance Required"
    case "highWaitTime":
      return "High Wait Time"
    case "queueThreshold":
      return "Queue Threshold Reached"
  }
}

