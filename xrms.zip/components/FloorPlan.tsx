import { useState, useEffect } from "react"
import { useSocket } from "../hooks/useSocket"

interface Machine {
  id: string
  name: string
  status: "available" | "in-use" | "maintenance"
}

export default function FloorPlan() {
  const [machines, setMachines] = useState<Machine[]>([])
  const socket = useSocket()

  useEffect(() => {
    // Fetch initial machine status
    fetch("/api/machines")
      .then((res) => res.json())
      .then((data) => setMachines(data))

    // Listen for machine updates
    socket.on("machineUpdated", (updatedMachine: Machine) => {
      setMachines((prevMachines) =>
        prevMachines.map((machine) => (machine.id === updatedMachine.id ? updatedMachine : machine)),
      )
    })

    return () => {
      socket.off("machineUpdated")
    }
  }, [socket])

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-semibold mb-6">Floor Plan</h2>
      <div className="grid grid-cols-3 gap-4">
        {machines.map((machine) => (
          <div
            key={machine.id}
            className={`aspect-square rounded-lg flex items-center justify-center text-white font-semibold ${getBackgroundColor(
              machine.status,
            )}`}
          >
            {machine.name}
          </div>
        ))}
      </div>
    </div>
  )
}

function getBackgroundColor(status: Machine["status"]) {
  switch (status) {
    case "available":
      return "bg-green-500"
    case "in-use":
      return "bg-yellow-500"
    case "maintenance":
      return "bg-red-500"
  }
}

