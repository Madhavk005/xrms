"use client"

import { useState, useEffect } from "react"
import { io } from "socket.io-client"
import MachineStatus from "./MachineStatus"
import FloorPlan from "./FloorPlan"
import WaitTimes from "./WaitTimes"
import UtilizationStats from "./UtilizationStats"

const socket = io("http://localhost:5000")

export default function Dashboard() {
  const [machines, setMachines] = useState([])
  const [waitTimes, setWaitTimes] = useState({})
  const [utilizationStats, setUtilizationStats] = useState({})

  useEffect(() => {
    const fetchData = async () => {
      const [machinesRes, waitTimesRes, utilizationRes] = await Promise.all([
        fetch("http://localhost:5000/api/machines"),
        fetch("http://localhost:5000/api/wait-times"),
        fetch("http://localhost:5000/api/utilization"),
      ])

      const machinesData = await machinesRes.json()
      const waitTimesData = await waitTimesRes.json()
      const utilizationData = await utilizationRes.json()

      setMachines(machinesData)
      setWaitTimes(waitTimesData)
      setUtilizationStats(utilizationData)
    }

    fetchData()

    socket.on("machineUpdated", (updatedMachine) => {
      setMachines((prevMachines) =>
        prevMachines.map((machine) => (machine.id === updatedMachine.id ? updatedMachine : machine)),
      )
    })

    socket.on("waitTimesUpdated", (newWaitTimes) => {
      setWaitTimes(newWaitTimes)
    })

    socket.on("utilizationUpdated", (newStats) => {
      setUtilizationStats(newStats)
    })

    return () => {
      socket.off("machineUpdated")
      socket.off("waitTimesUpdated")
      socket.off("utilizationUpdated")
    }
  }, [])

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <MachineStatus machines={machines} />
      <FloorPlan machines={machines} />
      <WaitTimes waitTimes={waitTimes} />
      <UtilizationStats stats={utilizationStats} />
    </div>
  )
}

