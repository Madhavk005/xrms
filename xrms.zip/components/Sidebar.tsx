"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { HomeIcon, ChartBarIcon, CogIcon, CalendarIcon, UserGroupIcon, WrenchIcon } from "@heroicons/react/24/outline"

const navigation = [
  { name: "Dashboard", href: "/dashboard", icon: HomeIcon },
  { name: "Analytics", href: "/dashboard/analytics", icon: ChartBarIcon },
  { name: "Appointments", href: "/dashboard/appointments", icon: CalendarIcon },
  { name: "Patients", href: "/dashboard/patients", icon: UserGroupIcon },
  { name: "Maintenance", href: "/dashboard/maintenance", icon: WrenchIcon },
  { name: "Settings", href: "/dashboard/settings", icon: CogIcon },
]

export default function Sidebar() {
  const pathname = usePathname()

  return (
    <div className="h-full flex flex-col bg-indigo-700">
      <div className="flex items-center justify-center h-16 bg-indigo-800">
        <img className="h-8 w-auto" src="/logo.svg" alt="XRMS" />
      </div>
      <nav className="mt-5 flex-1 px-2 space-y-1">
        {navigation.map((item) => (
          <Link
            key={item.name}
            href={item.href}
            className={`${
              pathname === item.href ? "bg-indigo-800 text-white" : "text-indigo-100 hover:bg-indigo-600"
            } group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors duration-150`}
          >
            <item.icon className="mr-3 flex-shrink-0 h-6 w-6" aria-hidden="true" />
            {item.name}
          </Link>
        ))}
      </nav>
    </div>
  )
}

