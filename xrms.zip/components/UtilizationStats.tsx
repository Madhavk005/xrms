import { useState, useEffect } from "react"
import { useSocket } from "../hooks/useSocket"

interface UtilizationStat {
  machine: string
  percentage: number
}

export default function UtilizationStats() {
  const [stats, setStats] = useState<UtilizationStat[]>([])
  const socket = useSocket()

  useEffect(() => {
    // Fetch initial utilization stats
    fetch("/api/utilization")
      .then((res) => res.json())
      .then((data) => setStats(data))

    // Listen for utilization updates
    socket.on("utilizationUpdated", (updatedStats: UtilizationStat[]) => {
      setStats(updatedStats)
    })

    return () => {
      socket.off("utilizationUpdated")
    }
  }, [socket])

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-semibold mb-6">Utilization Statistics</h2>
      <div className="space-y-4">
        {stats.map((stat) => (
          <div key={stat.machine}>
            <div className="flex justify-between mb-1">
              <span className="font-medium">{stat.machine}</span>
              <span className="text-sm font-semibold">{stat.percentage}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: `${stat.percentage}%` }}></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

