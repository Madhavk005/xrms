"use client"

import { useState } from "react"
import { Calendar } from "@/components/ui/calendar"

interface AppointmentCalendarProps {
  onSelectDate: (date: Date | null) => void
}

export default function AppointmentCalendar({ onSelectDate }: AppointmentCalendarProps) {
  const [date, setDate] = useState<Date | undefined>(new Date())

  const handleSelect = (newDate: Date | undefined) => {
    setDate(newDate)
    onSelectDate(newDate || null)
  }

  return <Calendar mode="single" selected={date} onSelect={handleSelect} className="rounded-md border" />
}

