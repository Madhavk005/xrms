import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"

interface Patient {
  id: string
  name: string
  dateOfBirth: string
  contactNumber: string
}

interface PatientListProps {
  patients: Patient[]
  onSelectPatient: (patient: Patient) => void
}

export default function PatientList({ patients, onSelectPatient }: PatientListProps) {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Name</TableHead>
          <TableHead>Date of Birth</TableHead>
          <TableHead>Contact Number</TableHead>
          <TableHead>Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {patients.map((patient) => (
          <TableRow key={patient.id}>
            <TableCell>{patient.name}</TableCell>
            <TableCell>{patient.dateOfBirth}</TableCell>
            <TableCell>{patient.contactNumber}</TableCell>
            <TableCell>
              <Button onClick={() => onSelectPatient(patient)}>Edit</Button>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  )
}

