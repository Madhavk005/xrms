"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"

interface Message {
  text: string
  sender: "user" | "bot"
}

export default function Chatbot() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")

  const handleSendMessage = async () => {
    if (!input.trim()) return

    const userMessage: Message = { text: input, sender: "user" }
    setMessages([...messages, userMessage])
    setInput("")

    // TODO: Implement actual chatbot logic
    const botResponse: Message = { text: "Thank you for your message. How can I assist you?", sender: "bot" }
    setTimeout(() => {
      setMessages((prevMessages) => [...prevMessages, botResponse])
    }, 1000)
  }

  return (
    <>
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: "spring", stiffness: 260, damping: 20 }}
      >
        <Button className="fixed bottom-4 right-4 rounded-full w-12 h-12" onClick={() => setIsOpen(!isOpen)}>
          💬
        </Button>
      </motion.div>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="fixed bottom-20 right-4 w-80 sm:w-96"
          >
            <Card>
              <CardHeader>
                <CardTitle>XRMS Assistant</CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[300px] pr-4">
                  {messages.map((message, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className={`mb-2 p-2 rounded-lg ${
                        message.sender === "user" ? "bg-blue-100 ml-auto" : "bg-gray-100"
                      }`}
                    >
                      {message.text}
                    </motion.div>
                  ))}
                </ScrollArea>
              </CardContent>
              <CardFooter>
                <form
                  onSubmit={(e) => {
                    e.preventDefault()
                    handleSendMessage()
                  }}
                  className="flex w-full space-x-2"
                >
                  <Input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Type your message..." />
                  <Button type="submit">Send</Button>
                </form>
              </CardFooter>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}

