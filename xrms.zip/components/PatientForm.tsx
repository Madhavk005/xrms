import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

interface Patient {
  id: string
  name: string
  dateOfBirth: string
  contactNumber: string
}

interface PatientFormProps {
  patient: Patient | null
  onSubmit: (patient: Omit<Patient, "id"> | Patient) => void
}

export default function PatientForm({ patient, onSubmit }: PatientFormProps) {
  const [name, setName] = useState("")
  const [dateOfBirth, setDateOfBirth] = useState("")
  const [contactNumber, setContactNumber] = useState("")

  useEffect(() => {
    if (patient) {
      setName(patient.name)
      setDateOfBirth(patient.dateOfBirth)
      setContactNumber(patient.contactNumber)
    } else {
      setName("")
      setDateOfBirth("")
      setContactNumber("")
    }
  }, [patient])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const patientData = { name, dateOfBirth, contactNumber }
    onSubmit(patient ? { ...patientData, id: patient.id } : patientData)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="name">Name</Label>
        <Input id="name" value={name} onChange={(e) => setName(e.target.value)} required />
      </div>
      <div>
        <Label htmlFor="dateOfBirth">Date of Birth</Label>
        <Input
          id="dateOfBirth"
          type="date"
          value={dateOfBirth}
          onChange={(e) => setDateOfBirth(e.target.value)}
          required
        />
      </div>
      <div>
        <Label htmlFor="contactNumber">Contact Number</Label>
        <Input id="contactNumber" value={contactNumber} onChange={(e) => setContactNumber(e.target.value)} required />
      </div>
      <Button type="submit">{patient ? "Update Patient" : "Add Patient"}</Button>
    </form>
  )
}

