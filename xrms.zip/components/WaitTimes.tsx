import { useState, useEffect } from "react"
import { useSocket } from "../hooks/useSocket"
import { ClockIcon } from "@heroicons/react/24/solid"

interface WaitTime {
  machine: string
  time: number
}

export default function WaitTimes() {
  const [waitTimes, setWaitTimes] = useState<WaitTime[]>([])
  const socket = useSocket()

  useEffect(() => {
    // Fetch initial wait times
    fetch("/api/wait-times")
      .then((res) => res.json())
      .then((data) => setWaitTimes(data))

    // Listen for wait time updates
    socket.on("waitTimesUpdated", (updatedWaitTimes: WaitTime[]) => {
      setWaitTimes(updatedWaitTimes)
    })

    return () => {
      socket.off("waitTimesUpdated")
    }
  }, [socket])

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-semibold mb-6">Wait Times</h2>
      <div className="space-y-4">
        {waitTimes.map((waitTime) => (
          <div key={waitTime.machine} className="flex items-center justify-between">
            <div className="flex items-center">
              <ClockIcon className="h-5 w-5 text-blue-500 mr-2" />
              <span className="font-medium">{waitTime.machine}</span>
            </div>
            <span className="text-lg font-semibold">{waitTime.time} min</span>
          </div>
        ))}
      </div>
    </div>
  )
}

