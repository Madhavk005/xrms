"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface AppointmentFormProps {
  selectedDate: Date | null
}

export default function AppointmentForm({ selectedDate }: AppointmentFormProps) {
  const [patientName, setPatientName] = useState("")
  const [patientId, setPatientId] = useState("")
  const [selectedTime, setSelectedTime] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    // TODO: Implement appointment scheduling logic
    console.log("Appointment scheduled:", { patientName, patientId, selectedDate, selectedTime })
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="patientName">Patient Name</Label>
        <Input id="patientName" value={patientName} onChange={(e) => setPatientName(e.target.value)} required />
      </div>
      <div>
        <Label htmlFor="patientId">Patient ID</Label>
        <Input id="patientId" value={patientId} onChange={(e) => setPatientId(e.target.value)} required />
      </div>
      <div>
        <Label htmlFor="appointmentDate">Appointment Date</Label>
        <Input id="appointmentDate" value={selectedDate ? selectedDate.toLocaleDateString() : ""} readOnly />
      </div>
      <div>
        <Label htmlFor="appointmentTime">Appointment Time</Label>
        <Select onValueChange={setSelectedTime}>
          <SelectTrigger>
            <SelectValue placeholder="Select a time" />
          </SelectTrigger>
          <SelectContent>
            {/* Add more time slots as needed */}
            <SelectItem value="09:00">09:00 AM</SelectItem>
            <SelectItem value="10:00">10:00 AM</SelectItem>
            <SelectItem value="11:00">11:00 AM</SelectItem>
            <SelectItem value="13:00">01:00 PM</SelectItem>
            <SelectItem value="14:00">02:00 PM</SelectItem>
            <SelectItem value="15:00">03:00 PM</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <Button type="submit">Schedule Appointment</Button>
    </form>
  )
}

