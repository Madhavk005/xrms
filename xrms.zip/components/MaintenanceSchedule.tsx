import { useState, useEffect } from "react"
import { useSocket } from "../hooks/useSocket"

interface MaintenanceEvent {
  id: string
  machineId: string
  machineName: string
  scheduledDate: string
  technician: string
}

export default function MaintenanceSchedule() {
  const [schedule, setSchedule] = useState<MaintenanceEvent[]>([])
  const socket = useSocket()

  useEffect(() => {
    // Fetch initial maintenance schedule
    fetch("/api/maintenance-schedule")
      .then((res) => res.json())
      .then((data) => setSchedule(data))

    // Listen for schedule updates
    socket.on("maintenanceScheduleUpdate", (updatedSchedule: MaintenanceEvent[]) => {
      setSchedule(updatedSchedule)
    })

    return () => {
      socket.off("maintenanceScheduleUpdate")
    }
  }, [socket])

  return (
    <div className="bg-white shadow rounded-lg p-4">
      <h2 className="text-lg font-semibold mb-4">Maintenance Schedule</h2>
      <ul className="space-y-2">
        {schedule.map((event) => (
          <li key={event.id} className="flex justify-between items-center">
            <span>{event.machineName}</span>
            <span>{new Date(event.scheduledDate).toLocaleDateString()}</span>
            <span>{event.technician}</span>
          </li>
        ))}
      </ul>
    </div>
  )
}

