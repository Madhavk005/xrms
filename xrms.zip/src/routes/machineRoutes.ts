import { Router } from "express"
import type { PrismaClient } from "@prisma/client"
import type { Server } from "socket.io"

export const machineRoutes = (prisma: PrismaClient, io: Server) => {
  const router = Router()

  router.get("/", async (req, res) => {
    try {
      const machines = await prisma.machine.findMany()
      res.json(machines)
    } catch (err) {
      res.status(500).json({ error: "An error occurred while fetching machines" })
    }
  })

  router.post("/", async (req, res) => {
    const { name, location, status } = req.body
    try {
      const newMachine = await prisma.machine.create({
        data: { name, location, status },
      })
      io.emit("machineAdded", newMachine)
      res.status(201).json(newMachine)
    } catch (err) {
      res.status(500).json({ error: "An error occurred while adding a machine" })
    }
  })

  router.put("/:id", async (req, res) => {
    const { id } = req.params
    const { status } = req.body
    try {
      const updatedMachine = await prisma.machine.update({
        where: { id: Number.parseInt(id) },
        data: { status },
      })
      io.emit("machineUpdated", updatedMachine)
      res.json(updatedMachine)
    } catch (err) {
      res.status(500).json({ error: "An error occurred while updating the machine" })
    }
  })

  return router
}

