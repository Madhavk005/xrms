import { Router } from "express"
import type { PrismaClient } from "@prisma/client"
import type { Server } from "socket.io"

export const scheduleRoutes = (prisma: PrismaClient, io: Server) => {
  const router = Router()

  router.post("/schedule", async (req, res) => {
    const { patientId, expectedDuration, priority } = req.body

    try {
      // Get all available machines
      const availableMachines = await prisma.machine.findMany({
        where: { status: "available" },
      })

      if (availableMachines.length === 0) {
        return res.status(400).json({ error: "No machines available" })
      }

      // Simple scheduling algorithm: choose the first available machine
      const selectedMachine = availableMachines[0]

      // Create a new schedule
      const newSchedule = await prisma.schedule.create({
        data: {
          machineId: selectedMachine.id,
          patientId,
          scheduledTime: new Date(),
          expectedDuration,
          priority,
        },
      })

      // Update machine status
      await prisma.machine.update({
        where: { id: selectedMachine.id },
        data: { status: "in-use" },
      })

      // Emit socket event for real-time updates
      io.emit("scheduleUpdated", newSchedule)

      res.status(201).json(newSchedule)
    } catch (err) {
      console.error(err)
      res.status(500).json({ error: "An error occurred while scheduling" })
    }
  })

  return router
}

