import type React from "react"
import { useState, useEffect } from "react"
import io from "socket.io-client"
import MachineStatus from "./MachineStatus"
import FloorPlan from "./FloorPlan"
import WaitTimes from "./WaitTimes"
import UtilizationStats from "./UtilizationStats"

const socket = io("http://localhost:5000")

const Dashboard: React.FC = () => {
  const [machines, setMachines] = useState([])
  const [waitTimes, setWaitTimes] = useState({})
  const [utilizationStats, setUtilizationStats] = useState({})

  useEffect(() => {
    // Fetch initial data
    fetchMachines()
    fetchWaitTimes()
    fetchUtilizationStats()

    // Set up Socket.io listeners
    socket.on("machineUpdated", (updatedMachine) => {
      setMachines((prevMachines) =>
        prevMachines.map((machine) => (machine.id === updatedMachine.id ? updatedMachine : machine)),
      )
    })

    socket.on("waitTimesUpdated", (newWaitTimes) => {
      setWaitTimes(newWaitTimes)
    })

    socket.on("utilizationUpdated", (newStats) => {
      setUtilizationStats(newStats)
    })

    return () => {
      socket.off("machineUpdated")
      socket.off("waitTimesUpdated")
      socket.off("utilizationUpdated")
    }
  }, [])

  const fetchMachines = async () => {
    const response = await fetch("http://localhost:5000/api/machines")
    const data = await response.json()
    setMachines(data)
  }

  const fetchWaitTimes = async () => {
    const response = await fetch("http://localhost:5000/api/wait-times")
    const data = await response.json()
    setWaitTimes(data)
  }

  const fetchUtilizationStats = async () => {
    const response = await fetch("http://localhost:5000/api/utilization")
    const data = await response.json()
    setUtilizationStats(data)
  }

  return (
    <div className="dashboard">
      <h1>X-Ray Machine Management Dashboard</h1>
      <div className="dashboard-grid">
        <MachineStatus machines={machines} />
        <FloorPlan machines={machines} />
        <WaitTimes waitTimes={waitTimes} />
        <UtilizationStats stats={utilizationStats} />
      </div>
    </div>
  )
}

export default Dashboard

