import type React from "react"

interface Machine {
  id: number
  name: string
  status: "available" | "in-use" | "maintenance"
}

interface MachineStatusProps {
  machines: Machine[]
}

const MachineStatus: React.FC<MachineStatusProps> = ({ machines }) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "available":
        return "green"
      case "in-use":
        return "yellow"
      case "maintenance":
        return "red"
      default:
        return "gray"
    }
  }

  return (
    <div className="machine-status">
      <h2>Machine Status</h2>
      <ul>
        {machines.map((machine) => (
          <li key={machine.id}>
            {machine.name}:
            <span className="status-indicator" style={{ backgroundColor: getStatusColor(machine.status) }}>
              {machine.status}
            </span>
          </li>
        ))}
      </ul>
    </div>
  )
}

export default MachineStatus

