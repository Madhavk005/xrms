import type React from "react"
import { BrowserRouter as Router, Route, Switch } from "react-router-dom"
import Dashboard from "./components/Dashboard"
import AdminPanel from "./components/AdminPanel"
import Header from "./components/Header"

const App: React.FC = () => {
  return (
    <Router>
      <div className="app">
        <Header />
        <Switch>
          <Route exact path="/" component={Dashboard} />
          <Route path="/admin" component={AdminPanel} />
        </Switch>
      </div>
    </Router>
  )
}

export default App

