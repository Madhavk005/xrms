import express from "express"
import { createServer } from "http"
import { Server } from "socket.io"
import cors from "cors"
import { PrismaClient } from "@prisma/client"
import { machineRoutes } from "./routes/machineRoutes"
import { scheduleRoutes } from "./routes/scheduleRoutes"
import { staffRoutes } from "./routes/staffRoutes"
import { maintenanceRoutes } from "./routes/maintenanceRoutes"

const app = express()
const httpServer = createServer(app)
const io = new Server(httpServer, {
  cors: {
    origin: "http://localhost:3000",
    methods: ["GET", "POST"],
  },
})

const prisma = new PrismaClient()

app.use(cors())
app.use(express.json())

app.use("/api/machines", machineRoutes(prisma, io))
app.use("/api/schedules", scheduleRoutes(prisma, io))
app.use("/api/staff", staffRoutes(prisma))
app.use("/api/maintenance", maintenanceRoutes(prisma, io))

io.on("connection", (socket) => {
  console.log("A user connected")

  socket.on("disconnect", () => {
    console.log("User disconnected")
  })
})

const PORT = process.env.PORT || 5000
httpServer.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
})

