import { useEffect, useState } from "react"
import io, { type Socket } from "socket.io-client"

export const useSocket = () => {
  const [socket, setSocket] = useState<Socket | null>(null)

  useEffect(() => {
    const socketIo = io("http://localhost:5000")

    setSocket(socketIo)

    return () => {
      socketIo.disconnect()
    }
  }, [])

  return socket as Socket
}

