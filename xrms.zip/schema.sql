CREATE TABLE machines (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  location VARCHAR(255) NOT NULL,
  status VARCHAR(50) NOT NULL,
  last_maintenance_date TIMESTAMP
);

CREATE TABLE staff (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  role VARCHAR(100) NOT NULL
);

CREATE TABLE usage_logs (
  id SERIAL PRIMARY KEY,
  machine_id INTEGER REFERENCES machines(id),
  patient_id VARCHAR(255) NOT NULL,
  start_time TIMESTAMP NOT NULL,
  end_time TIMESTAMP,
  staff_id INTEGER REFERENCES staff(id)
);

CREATE TABLE maintenance_logs (
  id SERIAL PRIMARY KEY,
  machine_id INTEGER REFERENCES machines(id),
  maintenance_date TIMESTAMP NOT NULL,
  description TEXT,
  performed_by INTEGER REFERENCES staff(id)
);

CREATE TABLE schedules (
  id SERIAL PRIMARY KEY,
  machine_id INTEGER REFERENCES machines(id),
  patient_id VARCHAR(255) NOT NULL,
  scheduled_time TIMESTAMP NOT NULL,
  expected_duration INTEGER NOT NULL,
  priority INTEGER NOT NULL
);

