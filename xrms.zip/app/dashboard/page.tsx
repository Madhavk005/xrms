import MachineStatus from "@/components/MachineStatus"
import FloorPlan from "@/components/FloorPlan"
import WaitTimes from "@/components/WaitTimes"
import UtilizationStats from "@/components/UtilizationStats"
import AlertsPanel from "@/components/AlertsPanel"
import MaintenanceSchedule from "@/components/MaintenanceSchedule"

export default function DashboardPage() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2">
        <MachineStatus />
      </div>
      <div className="lg:row-span-2">
        <AlertsPanel />
      </div>
      <div className="lg:col-span-2">
        <FloorPlan />
      </div>
      <div>
        <WaitTimes />
      </div>
      <div>
        <UtilizationStats />
      </div>
      <div>
        <MaintenanceSchedule />
      </div>
    </div>
  )
}

