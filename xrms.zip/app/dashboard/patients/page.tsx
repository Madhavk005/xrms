"use client"

import { useState, useEffect } from "react"
import PatientList from "../../../components/PatientList"
import PatientForm from "../../../components/PatientForm"

interface Patient {
  id: string
  name: string
  dateOfBirth: string
  contactNumber: string
}

export default function PatientsPage() {
  const [patients, setPatients] = useState<Patient[]>([])
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null)

  useEffect(() => {
    // TODO: Fetch patients from API
    const mockPatients: Patient[] = [
      { id: "1", name: "John Doe", dateOfBirth: "1980-01-01", contactNumber: "123-456-7890" },
      { id: "2", name: "Jane Smith", dateOfBirth: "1990-05-15", contactNumber: "987-654-3210" },
    ]
    setPatients(mockPatients)
  }, [])

  const handleAddPatient = (newPatient: Omit<Patient, "id">) => {
    // TODO: Implement API call to add patient
    const patientWithId = { ...newPatient, id: Date.now().toString() }
    setPatients([...patients, patientWithId])
  }

  const handleUpdatePatient = (updatedPatient: Patient) => {
    // TODO: Implement API call to update patient
    setPatients(patients.map((p) => (p.id === updatedPatient.id ? updatedPatient : p)))
    setSelectedPatient(null)
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div>
        <h2 className="text-2xl font-semibold mb-4">Patient List</h2>
        <PatientList patients={patients} onSelectPatient={setSelectedPatient} />
      </div>
      <div>
        <h2 className="text-2xl font-semibold mb-4">{selectedPatient ? "Edit Patient" : "Add New Patient"}</h2>
        <PatientForm patient={selectedPatient} onSubmit={selectedPatient ? handleUpdatePatient : handleAddPatient} />
      </div>
    </div>
  )
}

