"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import { motion } from "framer-motion"

interface MachineDetails {
  id: string
  name: string
  status: "available" | "in-use" | "maintenance"
  lastMaintenance: string
  totalUsageHours: number
  currentUser?: string
}

export default function MachinePage() {
  const { id } = useParams()
  const [machine, setMachine] = useState<MachineDetails | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchMachineDetails = async () => {
      try {
        const res = await fetch(`/api/machines/${id}`)
        if (!res.ok) throw new Error("Failed to fetch machine details")
        const data = await res.json()
        setMachine(data)
        setIsLoading(false)
      } catch (err) {
        setError("Failed to fetch machine details. Please try again later.")
        setIsLoading(false)
      }
    }

    fetchMachineDetails()
  }, [id])

  if (isLoading) return <div>Loading machine details...</div>
  if (error) return <div className="text-red-500">{error}</div>
  if (!machine) return <div>Machine not found</div>

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-white rounded-lg shadow-md p-6"
    >
      <h1 className="text-3xl font-semibold mb-6">{machine.name}</h1>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <h2 className="text-xl font-medium mb-2">Status</h2>
          <p className={`text-lg ${getStatusColor(machine.status)}`}>{machine.status}</p>
        </div>
        <div>
          <h2 className="text-xl font-medium mb-2">Last Maintenance</h2>
          <p className="text-lg">{new Date(machine.lastMaintenance).toLocaleDateString()}</p>
        </div>
        <div>
          <h2 className="text-xl font-medium mb-2">Total Usage Hours</h2>
          <p className="text-lg">{machine.totalUsageHours} hours</p>
        </div>
        {machine.currentUser && (
          <div>
            <h2 className="text-xl font-medium mb-2">Current User</h2>
            <p className="text-lg">{machine.currentUser}</p>
          </div>
        )}
      </div>
    </motion.div>
  )
}

function getStatusColor(status: MachineDetails["status"]) {
  switch (status) {
    case "available":
      return "text-green-600"
    case "in-use":
      return "text-yellow-600"
    case "maintenance":
      return "text-red-600"
  }
}

