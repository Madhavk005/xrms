"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { CalendarIcon, WrenchIcon } from "@heroicons/react/24/solid"

interface MaintenanceSchedule {
  id: string
  machineName: string
  date: string
  type: "routine" | "repair"
  technician: string
}

export default function MaintenanceSchedulePage() {
  const [schedule, setSchedule] = useState<MaintenanceSchedule[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchMaintenanceSchedule = async () => {
      try {
        const res = await fetch("/api/maintenance-schedule")
        if (!res.ok) throw new Error("Failed to fetch maintenance schedule")
        const data = await res.json()
        setSchedule(data)
        setIsLoading(false)
      } catch (err) {
        setError("Failed to fetch maintenance schedule. Please try again later.")
        setIsLoading(false)
      }
    }

    fetchMaintenanceSchedule()
  }, [])

  if (isLoading) return <div>Loading maintenance schedule...</div>
  if (error) return <div className="text-red-500">{error}</div>

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h1 className="text-3xl font-semibold mb-6">Maintenance Schedule</h1>
      <div className="space-y-4">
        {schedule.map((item, index) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-gray-50 rounded-lg p-4 flex items-center"
          >
            <CalendarIcon className="h-8 w-8 text-blue-500 mr-4" />
            <div className="flex-1">
              <h2 className="text-xl font-medium">{item.machineName}</h2>
              <p className="text-gray-600">{new Date(item.date).toLocaleDateString()}</p>
              <p className="text-sm text-gray-500">Technician: {item.technician}</p>
            </div>
            <div
              className={`px-3 py-1 rounded-full ${item.type === "routine" ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"}`}
            >
              {item.type === "routine" ? "Routine" : "Repair"}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

