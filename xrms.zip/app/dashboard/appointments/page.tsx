"use client"

import { useState } from "react"
import AppointmentCalendar from "@/components/AppointmentCalendar"
import AppointmentForm from "@/components/AppointmentForm"

export default function AppointmentsPage() {
  const [selectedDate, setSelectedDate] = useState<Date | null>(null)

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div>
        <h2 className="text-2xl font-semibold mb-4">Appointment Calendar</h2>
        <AppointmentCalendar onSelectDate={setSelectedDate} />
      </div>
      <div>
        <h2 className="text-2xl font-semibold mb-4">Schedule Appointment</h2>
        <AppointmentForm selectedDate={selectedDate} />
      </div>
    </div>
  )
}

