import { NextResponse } from "next/server"

export async function GET() {
  // In a real application, you would fetch this data from a database
  const maintenanceSchedule = [
    {
      id: "1",
      machineName: "X-Ray Machine 1",
      date: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(),
      type: "routine",
      technician: "John Doe",
    },
    {
      id: "2",
      machineName: "X-Ray Machine 2",
      date: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString(),
      type: "repair",
      technician: "Jane Smith",
    },
    {
      id: "3",
      machineName: "X-Ray Machine 3",
      date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      type: "routine",
      technician: "Bob Johnson",
    },
  ]

  return NextResponse.json(maintenanceSchedule)
}

