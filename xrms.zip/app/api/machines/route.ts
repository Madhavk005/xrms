import { NextResponse } from "next/server"
import type { Machine } from "@/types"

export async function GET() {
  // In a real application, you would fetch this data from a database
  const machines: Machine[] = [
    { id: "1", name: "X-Ray Machine 1", status: "available" },
    { id: "2", name: "X-Ray Machine 2", status: "in-use" },
    { id: "3", name: "X-Ray Machine 3", status: "maintenance" },
  ]

  return NextResponse.json(machines)
}

