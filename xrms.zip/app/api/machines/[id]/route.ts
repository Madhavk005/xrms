import { NextResponse } from "next/server"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  const id = params.id

  // In a real application, you would fetch this data from a database
  const machineDetails = {
    id,
    name: `X-Ray Machine ${id}`,
    status: ["available", "in-use", "maintenance"][Math.floor(Math.random() * 3)],
    lastMaintenance: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
    totalUsageHours: Math.floor(Math.random() * 1000),
    currentUser: Math.random() > 0.5 ? "Dr. Smith" : undefined,
  }

  return NextResponse.json(machineDetails)
}

