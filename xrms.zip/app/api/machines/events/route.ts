import { NextResponse } from "next/server"

export async function GET() {
  const stream = new ReadableStream({
    start(controller) {
      const encoder = new TextEncoder()
      const sendEvent = (data: string) => {
        controller.enqueue(encoder.encode(`data: ${data}\n\n`))
      }

      // Simulate real-time updates
      const interval = setInterval(() => {
        const machineId = Math.floor(Math.random() * 3) + 1
        const statuses = ["available", "in-use", "maintenance"]
        const status = statuses[Math.floor(Math.random() * statuses.length)]
        const update = JSON.stringify({ id: machineId.toString(), status })
        sendEvent(update)
      }, 5000)

      // Clean up the interval when the connection is closed
      return () => clearInterval(interval)
    },
    cancel() {
      // This is called if the client closes the connection
      console.log("Client closed the connection")
    },
  })

  return new NextResponse(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  })
}

