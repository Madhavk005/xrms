import { NextResponse } from "next/server"

export async function GET() {
  const stream = new ReadableStream({
    start(controller) {
      const encoder = new TextEncoder()
      const sendEvent = (data: string) => {
        controller.enqueue(encoder.encode(`data: ${data}\n\n`))
      }

      // Simulate real-time alerts
      const interval = setInterval(() => {
        const types = ["breakdown", "maintenance", "highWaitTime", "queueThreshold"]
        const type = types[Math.floor(Math.random() * types.length)]
        const alert = {
          id: Date.now().toString(),
          type,
          message: `New ${type} alert`,
          timestamp: new Date().toISOString(),
        }
        sendEvent(JSON.stringify(alert))
      }, 10000)

      // Clean up the interval when the connection is closed
      return () => clearInterval(interval)
    },
    cancel() {
      // This is called if the client closes the connection
      console.log("Client closed the connection")
    },
  })

  return new NextResponse(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  })
}

