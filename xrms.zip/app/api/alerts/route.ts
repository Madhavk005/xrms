import { NextResponse } from "next/server"
import type { Alert } from "@/types"

export async function GET() {
  // In a real application, you would fetch this data from a database
  const alerts: Alert[] = [
    {
      id: "1",
      type: "breakdown",
      message: "X-Ray Machine 2 has broken down",
      timestamp: new Date().toISOString(),
    },
    {
      id: "2",
      type: "maintenance",
      message: "X-Ray Machine 3 requires scheduled maintenance",
      timestamp: new Date().toISOString(),
    },
    {
      id: "3",
      type: "highWaitTime",
      message: "Wait time for X-Ray Machine 1 exceeds 30 minutes",
      timestamp: new Date().toISOString(),
    },
  ]

  return NextResponse.json(alerts)
}

