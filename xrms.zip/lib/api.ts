import type { Machine, Alert, MaintenanceSchedule, Appointment, Patient } from "@/types"

export async function fetchMachines(): Promise<Machine[]> {
  const response = await fetch("/api/machines")
  if (!response.ok) {
    throw new Error("Failed to fetch machines")
  }
  return response.json()
}

export function subscribeToMachineUpdates(callback: (machine: Machine) => void): () => void {
  const eventSource = new EventSource("/api/machines/events")

  eventSource.onmessage = (event) => {
    const updatedMachine = JSON.parse(event.data)
    callback(updatedMachine)
  }

  return () => {
    eventSource.close()
  }
}

export async function fetchAlerts(): Promise<Alert[]> {
  const response = await fetch("/api/alerts")
  if (!response.ok) {
    throw new Error("Failed to fetch alerts")
  }
  return response.json()
}

export function subscribeToAlerts(callback: (alert: Alert) => void): () => void {
  const eventSource = new EventSource("/api/alerts/events")

  eventSource.onmessage = (event) => {
    const newAlert = JSON.parse(event.data)
    callback(newAlert)
  }

  return () => {
    eventSource.close()
  }
}

export async function fetchMaintenanceSchedule(): Promise<MaintenanceSchedule[]> {
  const response = await fetch("/api/maintenance-schedule")
  if (!response.ok) {
    throw new Error("Failed to fetch maintenance schedule")
  }
  return response.json()
}

export async function fetchAppointments(): Promise<Appointment[]> {
  const response = await fetch("/api/appointments")
  if (!response.ok) {
    throw new Error("Failed to fetch appointments")
  }
  return response.json()
}

export async function createAppointment(appointment: Omit<Appointment, "id">): Promise<Appointment> {
  const response = await fetch("/api/appointments", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(appointment),
  })
  if (!response.ok) {
    throw new Error("Failed to create appointment")
  }
  return response.json()
}

export async function fetchPatients(): Promise<Patient[]> {
  const response = await fetch("/api/patients")
  if (!response.ok) {
    throw new Error("Failed to fetch patients")
  }
  return response.json()
}

export async function createPatient(patient: Omit<Patient, "id">): Promise<Patient> {
  const response = await fetch("/api/patients", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(patient),
  })
  if (!response.ok) {
    throw new Error("Failed to create patient")
  }
  return response.json()
}

export async function updatePatient(patient: Patient): Promise<Patient> {
  const response = await fetch(`/api/patients/${patient.id}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(patient),
  })
  if (!response.ok) {
    throw new Error("Failed to update patient")
  }
  return response.json()
}

